#include<stdio.h>
#include<string.h> //strlen
#include<sys/socket.h>
#include<arpa/inet.h> //inet_addr
#include<unistd.h> //write
 
int main(int argc , char *argv[])
{
 int socket_desc , client_sock , c , read_size;
 struct sockaddr_in server , client;
 int message,i;
 char msg[100];
 //Create socket
 socket_desc = socket(AF_INET , SOCK_STREAM , 0);
 if (socket_desc == -1)
 {
 printf("Could not create socket");
 }
 puts("Socket created");
 
 //Prepare the sockaddr_in structure
 server.sin_family = AF_INET;
 server.sin_addr.s_addr = INADDR_ANY;
 server.sin_port = htons( 8880 );
 
 //Bind
 if( bind(socket_desc,(struct sockaddr *)&server , sizeof(server)) < 0)
 {
 //print the error message
 perror("bind failed. Error");
 return 1;
 }
 puts("bind done");
 
 //Listen
 listen(socket_desc , 3);
 
 //Accept and incoming connection
 puts("Waiting for incoming connections...");
 c = sizeof(struct sockaddr_in);
 
 //accept connection from an incoming client
 client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c);
 if (client_sock < 0)
 {
 perror("accept failed");
 return 1;
 }
 puts("Connection accepted");
 
 //Receive a message from client
 while( (read_size = recv(client_sock ,&message , sizeof(int), 0)) > 0 )
 {
 // print client msg at server side
 puts("The number sent by client is: ");

 if(message>100||message<0)
 strncpy(msg,"incorrect marks",sizeof(msg));
 else if(message>=85&&message<=100)
 strncpy(msg,"Grade A",sizeof(msg));
else if(message>=70&&message<=84)
 strncpy(msg,"Grade B",sizeof(msg));
else if(message>=60&&message<=69)
strncpy(msg,"Grade C",sizeof(msg));
else if(message>=50&&message<=59)
 strncpy(msg,"Grade D",sizeof(msg));
else if(message>=0&&message<=49)
 strncpy(msg,"Fail",sizeof(msg));
 
printf("%s",msg);
 write(client_sock , &msg, 100*sizeof(char));
 
 }
 
 if(read_size == 0)
 {
 puts("Client disconnected");
 }
 else if(read_size == -1)
 {
 perror("recv failed");
 }
 
 return 0;
}
 

